Name: Shrenik
Univ ID: AZ61492
IP Addresses:
Entry point using VPN: 130.85.220.34
Ubuntu22: 133.228.81.2
Ubuntu20: 133.228.81.3
Kali Linux: 133.228.81.1

Challenges faced: 
1) ufw - when firewall enabled: ssh traffic is also blocked. so we have to use:

sudo ufw allow ssh

before we enable.

2) small other issues which were solved easily with slight changes in commands.

Summary of overall learning:

We have first connected to the entry point through the VPN provided, then we sshed into the required vms via their IP addresses as given previously.

Then we have launched various attacks such as icmp flood attack, ICMP smurf, UDP flood and so on. 
This is a serious issue in real life and knowing how to enable firewall at the required system is quite important and this assignment has taught us how to do it in different scenarios. 

All the used commands are mentioned in the attached Attack.txt. Details are given deeply in the file of how the attack was launched. and how we prevented it using ufw and Syn Cookies. 

ICMP flood attack:
This is basically launched via hping3 with given ip address of victim. ICMP (Internet Control Message Protocol) flood attack is a type of Denial of Service (DoS) attack that involves sending a large number of ICMP packets to overwhelm the victim's network and cause it to become unavailable to legitimate users. 

we have used ufw to block that traffic. 

ICMP Smruf attack:
A Smurf attack is a type of DDoS (Distributed Denial of Service) attack that uses spoofed ICMP packets to flood a target network with traffic. 

the commands used in prevention is mentioned in the attached file.

Similar with other attacks..,

Coming to TCP SYN Cookies..,

When the configuration option net.ipv4.tcp_syncookies is set to 1, the system responds to SYN queries initially normally until the SYN response queue fills up in accordance with the value of net.ipv4.tcp_max_syn_backlog (which is 256 by default). The system then uses SYN cookies to respond to subsequent TCP SYN requests for new connection requests. Specific procedures must be followed in order to confirm the functionality of SYN cookies.

here we created a jpg file on the ubuntu20 machine and fetched it using kali linux.

In the attached folder, i have extracted scripts from both Kali Linux and UBUNTU 20 machines to prove the attacks and preventions. 
